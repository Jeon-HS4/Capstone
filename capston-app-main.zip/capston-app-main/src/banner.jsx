import React, { useState, useEffect } from 'react';
import styled from 'styled-components';

const BannerContainer = styled.div`
  width: 100%;
  overflow: hidden;
`;

const BannerWrapper = styled.div`
  display: flex;
  transition: transform 1s ease;
`;

const BannerItem = styled.div`
  flex: 0 0 100%;
`;

const banners = [
  { id: 1, content: "첫 번째 배너" },
  { id: 2, content: "두 번째 배너" },
  { id: 3, content: "세 번째 배너" }
];

const Banner = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex(prevIndex => (prevIndex + 1) % banners.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <BannerContainer>
      <BannerWrapper style={{ transform: `translateX(-${index * 100}%)` }}>
        {banners.map(banner => (
          <BannerItem key={banner.id}>
            <p>{banner.content}</p>
          </BannerItem>
        ))}
      </BannerWrapper>
    </BannerContainer>
  );
};

export default Banner;
