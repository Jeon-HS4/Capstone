import React from 'react';
import styled from 'styled-components';
import WeatherBanner from '../weather/WeatherBanner';

const DashboardWrapper = styled.div`
  display: flex;
  flex-direction: column;
  padding: 20px;
  background-color: #f4f7fa;
  min-height: 100vh;
`;

const TopSectionWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const MapWrapper = styled.div`
  flex: 1 1 70%;
  background-color: #ffffff;
  padding: 15px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
  height: 500px;  
  background: url('/사과.jpg') no-repeat center center;
  background-size: contain;
`;

const InfoSectionWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const InfoCard = styled.div`
  flex: 1 1 48%;
  background-color: #ffffff;
  padding: 15px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
`;

const SectionHeader = styled.h3`
  margin-bottom: 10px;
  font-size: 1.2rem;
  color: #333;
`;

const Dashboard = () => {
  const mapHeight = '500px';

  return (
    <DashboardWrapper>
      <TopSectionWrapper>
        <MapWrapper />
        <WeatherBanner height={mapHeight} />
      </TopSectionWrapper>
      <InfoSectionWrapper>
        <InfoCard>
          <SectionHeader>미세먼지</SectionHeader>
          <p>주요 특징에 대한 설명을 여기에 적어주세요.</p>
        </InfoCard>
        <InfoCard>
          <SectionHeader>미세먼지</SectionHeader>
          <p>주요 특징에 대한 설명을 여기에 적어주세요.</p>
        </InfoCard>
      </InfoSectionWrapper>
      <InfoSectionWrapper>
        <InfoCard>
          <SectionHeader>미세먼지</SectionHeader>
          <p>주요 특징에 대한 설명을 여기에 적어주세요.</p>
        </InfoCard>
        <InfoCard>
          <SectionHeader>미세먼지</SectionHeader>
          <p>주요 특징에 대한 설명을 여기에 적어주세요.</p>
        </InfoCard>
      </InfoSectionWrapper>
    </DashboardWrapper>
  );
};

export default Dashboard;
