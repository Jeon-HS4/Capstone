import React from 'react';
import Slider from 'react-slick';
import styled from 'styled-components';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

const BannerContainer = styled.div`
  width: 100%;
  max-width: 300px;
  height: ${({ height }) => height || 'auto'};
  background-color: #ffffff;
  padding: 15px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-left: 20px;
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

const CardWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 10px;
  background-color: #f0f7ff;
  border: 1px solid #e0e7ef;
  border-radius: 8px;
  margin: 0 10px;
  height: 500px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const CardTitle = styled.h4`
  margin: 0;
  font-size: 1rem;
  color: #333;
`;

const CardValue = styled.p`
  font-size: 1.5rem;
  font-weight: bold;
  color: #007bff;
`;

const CustomArrow = styled.div`
  display: block;
  width: 30px;
  height: 30px;
  background-color: rgba(0, 0, 0, 0.5);
  border-radius: 50%;
  color: #fff;
  font-size: 14px;
  line-height: 30px;
  text-align: center;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  z-index: 1;

  &::before {
    content: ${({ direction }) => `"${direction === 'next' ? '>' : '<'}"`};
    color: #fff;
  }

  ${({ direction }) =>
    direction === 'next'
      ? 'right: -15px;'
      : 'left: -15px;'}
`;

const WeatherBanner = ({ height }) => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  const weatherData = [
    { title: 'Temperature (°C)', value: '25°C' },
    { title: 'Wind Speed (m/s)', value: '5 m/s' },
    { title: 'Fine Dust (µg/m³)', value: '40 µg/m³' },
    { title: 'Humidity (%)', value: '55%' },
    { title: 'Precipitation (mm)', value: '12 mm' },
  ];

  return (
    <BannerContainer height={height}>
      <Slider {...settings}>
        {weatherData.map((item, index) => (
          <CardWrapper key={index}>
            <CardTitle>{item.title}</CardTitle>
            <CardValue>{item.value}</CardValue>
          </CardWrapper>
        ))}
      </Slider>
    </BannerContainer>
  );
};

export default WeatherBanner;
